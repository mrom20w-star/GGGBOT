require('dotenv').config();

const { Client, GatewayIntentBits, AttachmentBuilder, Events } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');

const token = (process.env.DISCORD_TOKEN || '').trim();
const welcomeChannelId = (process.env.WELCOME_CHANNEL_ID || '').trim();

if (!token || token === 'PASTE_NEW_BOT_TOKEN_HERE') {
  console.error('\n❌ التوكن غير مضبوط. افتح ملف .env وضع التوكن الجديد بعد DISCORD_TOKEN=');
  console.error('مهم: اعمل Reset Token في Discord Developer Portal لأن التوكن السابق اتشارك في المحادثة.\n');
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

async function makeWelcomeCard(member) {
  const canvas = createCanvas(1000, 360);
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createLinearGradient(0, 0, 1000, 360);
  gradient.addColorStop(0, '#10172e');
  gradient.addColorStop(0.55, '#18264b');
  gradient.addColorStop(1, '#0a0f1f');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 1000, 360);

  ctx.globalAlpha = 0.18;
  ctx.fillStyle = '#39e6c3';
  ctx.beginPath(); ctx.arc(900, 40, 170, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#6487ff';
  ctx.beginPath(); ctx.arc(80, 330, 150, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;

  ctx.strokeStyle = '#3ce6c4'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.roundRect(18, 18, 964, 324, 28); ctx.stroke();

  const avatarUrl = member.user.displayAvatarURL({ extension: 'png', size: 256 });
  const avatar = await loadImage(avatarUrl);
  const x = 755, y = 82, size = 160;
  ctx.save();
  ctx.beginPath(); ctx.arc(x + size / 2, y + size / 2, size / 2 + 7, 0, Math.PI * 2);
  ctx.fillStyle = '#3ce6c4'; ctx.fill();
  ctx.beginPath(); ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2); ctx.clip();
  ctx.drawImage(avatar, x, y, size, size);
  ctx.restore();

  const displayName = (member.user.globalName || member.user.username).slice(0, 22);
  ctx.textAlign = 'right';
  ctx.fillStyle = '#3ce6c4'; ctx.font = 'bold 32px sans-serif';
  ctx.fillText('WELCOME TO THE SERVER', 710, 105);
  ctx.fillStyle = '#ffffff'; ctx.font = 'bold 42px sans-serif';
  ctx.fillText(displayName, 710, 175);
  ctx.fillStyle = '#c9d5f2'; ctx.font = '26px sans-serif';
  ctx.fillText('نورت السيرفر يا بطل 💙', 710, 225);
  ctx.fillStyle = '#9baed8'; ctx.font = '20px sans-serif';
  ctx.fillText(`MEMBER #${member.guild.memberCount}`, 710, 278);

  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffffff'; ctx.font = 'bold 26px sans-serif';
  ctx.fillText('✨ أهلاً وسهلاً ✨', 55, 90);
  ctx.fillStyle = '#b9c8ea'; ctx.font = '21px sans-serif';
  ctx.fillText('سعداء بانضمامك إلينا', 55, 132);
  ctx.fillText('اقرأ القوانين واستمتع بوقتك', 55, 166);
  return canvas.toBuffer('image/png');
}

client.once(Events.ClientReady, readyClient => {
  console.log(`✅ البوت اشتغل بنجاح باسم: ${readyClient.user.tag}`);
  console.log('👋 في انتظار عضو جديد...');
});

client.on(Events.GuildMemberAdd, async member => {
  try {
    let channel = welcomeChannelId
      ? await member.guild.channels.fetch(welcomeChannelId).catch(() => null)
      : member.guild.systemChannel;

    if (!channel || !channel.isTextBased() || typeof channel.send !== 'function') {
      channel = member.guild.channels.cache.find(ch => {
        if (!ch.isTextBased() || typeof ch.send !== 'function') return false;
        const perms = ch.permissionsFor(member.guild.members.me);
        return perms?.has('SendMessages') && perms?.has('AttachFiles');
      });
    }
    if (!channel) {
      console.error(`❌ لم أجد قناة مناسبة للإرسال في ${member.guild.name}. راجع ID القناة والصلاحيات.`);
      return;
    }

    const buffer = await makeWelcomeCard(member);
    const attachment = new AttachmentBuilder(buffer, { name: 'welcome.png' });
    await channel.send({
      content: `🎉 أهلاً وسهلاً ${member}!\nنورت **${member.guild.name}** — أنت العضو رقم **${member.guild.memberCount}** 💙`,
      files: [attachment],
      allowedMentions: { users: [member.id] }
    });
    console.log(`👋 تم الترحيب بـ ${member.user.tag} في ${member.guild.name}`);
  } catch (error) {
    console.error('❌ خطأ أثناء الترحيب:', error);
  }
});

client.login(token).catch(error => {
  console.error('\n❌ فشل تسجيل الدخول إلى Discord.');
  if (error.code === 'TokenInvalid' || /token/i.test(error.message || '')) {
    console.error('التوكن غير صحيح. اعمل Reset Token واستخدم التوكن الجديد داخل .env.');
  } else {
    console.error(error);
  }
  process.exit(1);
});
